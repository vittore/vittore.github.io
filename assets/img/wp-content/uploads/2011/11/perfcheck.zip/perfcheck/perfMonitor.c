/**
A USB interface to the Microchip perf USB board
  Vittore Zen, vittore@zen.pn.it, 2011

*/
#include <usb.h>				 
#include <unistd.h>			
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <sys/timex.h>



FILE *fr;		
	

const static int vendorID=0x04d8;// Microchip, Inc
const static int productID=0x0044;
const static int configuration=1;/*  Configuration 1*/
const static int interface=0;	 /* Interface 0 */

const static int endpoint_in=0x81;
const static int endpoint_out=1; /* endpoint 1 address for OUT */

const static int timeout=5000;	 /* timeout in ms */

const static int reqLen=8;
typedef unsigned char byte;

unsigned long  long int lv1, lv2,rv1,rv2,lev1,lev2;
int left,right,led;

 char leftComunity[255];
 char leftIP[255];
 char leftMIB[255];
 char rightComunity[255];
 char rightIP[255];
 char rightMIB[255];
 char ledComunity[255];
 char ledIP[255];
 char ledMIB[255];
long int leftMax,rightMax,ledMax,sleepTime;

char leftCmd[255];
char rightCmd[255];
char ledCmd[255];



struct ntptimeval start, elapsed;
struct usb_dev_handle * perf_fs_usb;



unsigned long  long int umin (const unsigned long  long int a, const unsigned long  long int b) {
	if (a<b) 
		return a;
	return b;
	}

void bad(const char *why)
{
	fprintf(stderr,"Fatal error> %s\n",why);
	exit(17);
}


extern int usb_debug;

struct usb_dev_handle *usb_perf_fs_usb_open(void)
{
	struct usb_device * device;
	struct usb_bus * bus;
	char string[50];

	#ifndef WIN32
	if( geteuid()!=0 )
		bad("This program must be run as root, or made setuid root");
	#endif
	#ifdef USB_DEBUG
	usb_debug=4;
	#endif

	printf("Locating Microchip(tm) perfMonitor board (vendor 0x%04x/product 0x%04x)\n", vendorID, productID);
	//usb_set_debug(255);
	//printf("setting USB debug on by adding usb_set_debug(255) \n");

	usb_init();
	usb_find_busses();
	usb_find_devices();

	for (bus=usb_get_busses();bus!=NULL;bus=bus->next)
	{
		struct usb_device * usb_devices = bus->devices;
		
		

		for( device=usb_devices; device!=NULL; device=device->next )
		{
			if( device->descriptor.idVendor == vendorID &&
				device->descriptor.idProduct == productID )
			{
				struct usb_dev_handle *d;
				printf("Found USB perfMonitor board as device '%s' on USB bus %s\n",
					device->filename,
					device->bus->dirname);
				//usb_reset(d);
				d = usb_open(device);

				if( d )
				{
					int retval;
					char dname[32] = {0};
					retval = usb_get_driver_np(d, 0, dname, 31);
					if (!retval)
					{
						if (usb_detach_kernel_driver_np(d,interface))
						{
							printf("Device detached successfully from the kernel\n");
						}
						else
						{
							printf("Error detaching the device :-( \n");
						}
					}

					if( usb_set_configuration(d, configuration) )
					{
						bad("Error setting USB configuration.\n");
					}
					retval=usb_claim_interface(d, interface) ;
					if( retval)
					{
						bad("Claim failed-- the USB perf FS USB is in use by another driver.\n");
					}
					printf("Communication established.\n");

					printf("Interface Claim Status : %d\n",retval);

					printf("Device Protocol : %d\n",device->descriptor.bDeviceProtocol);
					printf("Report Length : %d\n",device->descriptor.bLength);
					printf("Decriptor Type : %d\n",device->descriptor.bDescriptorType);
					printf("End Points : %d\n",device->config->interface->altsetting->bNumEndpoints);
					printf("Interface Class : %d\n",device->config->interface->altsetting->bInterfaceClass);
					printf("Protocol : %d\n",device->config->interface->altsetting->bInterfaceProtocol);
					printf("Interface Number: %d\n",device->config->interface->altsetting->bInterfaceNumber);
					printf("Device Filename : %s\n",device->filename);

					usb_get_string_simple(d,device->descriptor.iManufacturer,string,sizeof(string));
					printf("Device Manfucaturer : %s\n",string);
					usb_get_string_simple(d,device->descriptor.iProduct,string,sizeof(string));
					printf("Product Name : %s\n",string);
					usb_get_string_simple(d,device->descriptor.iSerialNumber,string,sizeof(string));
					printf("Device Serial Number: %s\n",string);
					printf("End point addresses : 0x%x\n",device->config->interface->altsetting->endpoint->bEndpointAddress);

					return d;
				}
				else
					bad("Open failed for USB device");
			}

		}
	}
	bad("Could not find USB  board--\n"
		"you might try lsusb to see if it's actually there.");
	return NULL;
}


static void send_usb(struct usb_dev_handle * d, int len, const char * src)
{
	int r = usb_interrupt_write(d, endpoint_out, (char *)src, len, timeout);
	if( r < 0 )
	{
		perror("usb write"); 
		//usb_reset(d);
	}
}


static void recv_usb(struct usb_dev_handle * d, int len, byte * dest)
{
	//   int i;
	int r = usb_interrupt_read(d, endpoint_in, dest, len, timeout);
	if( r != len )
	{
		//usb_reset(d);
		
	}
}


void writeUSB(struct usb_dev_handle * d, int l, int r,int led)
{
	
	byte answer[3];
	byte question[8];
	question[0]=0x80;
	question[1]=l;
	question[2]=r;
	question[3]=0;
	question[4]=0;
	question[5]=0;
	question[6]=0;

	if (led>80) question[3]=255;
	if ((led>50) && (led<80)) question[4]=100;
	if (led<50) question[5]=100;
	if (led<20) {
		question[3]=0;
		question[4]=0;
		question[5]=0;
	}
	
	send_usb(d,  8,question);

	recv_usb(d, 2, answer);

}


void getValues() {
	char line[100];


		remove("/tmp/value.txt");
		system(leftCmd);
		system(rightCmd);
		system(ledCmd);

	lv1=lv2;
	rv1=rv2;
	lev1=lev2;
	
	fr = fopen ("/tmp/value.txt", "r");
	fgets(line, 80, fr) ;
	sscanf (line, "%llu", &lv2);
	fgets(line, 80, fr) ;
	sscanf (line, "%llu", &rv2);
	fgets(line, 80, fr) ;
	sscanf (line, "%llu", &lev2);
	fclose(fr);

}





void getConfig ()
{
	FILE *fc;
  char key[100];
  char value[200];
  char row[1024];
	
 char *p;

  fc=fopen("current.cfg","r");
  while (!feof(fc) ){
	   fgets(row,200,fc);
	  
	  if (strlen(row)<4) continue;
    if( sscanf(row,"%[^=]=%[^=\n]",key,value)==2 ) {
        if (strlen(key)<4) continue;
	if (strcmp (key,"sleepTime")==0) sleepTime=strtol(value,&p, 10);
	if (strcmp(key,"leftComunity")==0) strcpy(leftComunity,value);
	if (strcmp(key,"leftIP")==0) strcpy(leftIP,value);
	if (strcmp(key,"leftMIB")==0) strcpy(leftMIB,value);
	if (strcmp(key,"rightComunity")==0) strcpy(rightComunity,value);
	if (strcmp(key,"rightIP")==0) strcpy(rightIP,value);
	if (strcmp(key,"rightMIB")==0) strcpy(rightMIB,value);
	if (strcmp(key,"ledComunity")==0) strcpy(ledComunity,value);
	if (strcmp(key,"ledIP")==0) strcpy(ledIP,value);
	if (strcmp(key,"ledMIB")==0) strcpy(ledMIB,value);
	if (strcmp(key,"leftMax")==0) leftMax=strtol (value, &p, 10);
	if (strcmp(key,"rightMax")==0) rightMax=strtol (value, &p, 10);
	if (strcmp(key,"ledMax")==0) ledMax=strtol (value, &p, 10);
   }

}   
	fclose(fc);
	
	sprintf(leftCmd,"snmpget -v 1 -c \"%s\"  %s %s   | awk '{print $4 >> \"/tmp/value.txt\" }'",    leftComunity,leftIP,leftMIB);
	sprintf(rightCmd,"snmpget -v 1 -c \"%s\"  %s %s   | awk '{print $4 >> \"/tmp/value.txt\" }'",   rightComunity,rightIP,rightMIB);
	sprintf(ledCmd,"snmpget -v 1 -c \"%s\"  %s %s   | awk '{print $4 >> \"/tmp/value.txt\" }'", ledComunity,ledIP,ledMIB);
	}

static int difference_micro(struct ntptimeval *bBefore,
struct ntptimeval *aAfter)
{
	return (signed long long) aAfter->time.tv_sec * 1000000ll +
	       (signed long long) aAfter->time.tv_usec -
	       (signed long long) bBefore->time.tv_sec * 1000000ll -
	       (signed long long) bBefore->time.tv_usec;
}




int main(int argc, char ** argv)
{
	int difference;
	//struct ntptimeval start, elapsed;
	
	
	struct usb_dev_handle * perf_fs_usb = usb_perf_fs_usb_open();

	getConfig();
	
	printf("Starting monitoring:\n");

	ntp_gettime(&start);
	getValues();

while(1) {

usleep(sleepTime);
	getValues();

	ntp_gettime(&elapsed);
	difference=difference_micro(&start, &elapsed) ;
	ntp_gettime(&start);
	left=umin((lv2-lv1)*800/difference/leftMax ,100);
	right=umin((rv2-rv1)*800/difference/rightMax ,100);
	led=umin((lev2-lev1)*800/difference/ledMax ,100);
	printf ("sleep %i ",difference);
	printf ("display: %i %i %i\n",right,left, led);
writeUSB(perf_fs_usb,right,left,led);
	
	   
   } 
   
   
   
   	  usb_close(perf_fs_usb);
	   return 0;

}
