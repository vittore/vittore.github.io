#!/bin/bash
# Rif. per il calcolo della banda
# http://www.cisco.com/en/US/tech/tk648/tk362/technologies_tech_note09186a008009496e.shtml

drop=11

comunityFastweb="ilgava.com"
ipFastweb=93.62.201.193


for (( ; ; ))
do

ifInOctetsFirstFastweb=`snmpget -v 1 -c $comunityFastweb  $ipFastweb IF-MIB::ifInOctets.2   | awk '{print $4}'`
ifOutOctetsFirstFastweb=`snmpget -v 1 -c $comunityFastweb $ipFastweb IF-MIB::ifOutOctets.2   | awk '{print $4}'`

sleep 1
ifInOctetsLastFastweb=`snmpget -v 1 -c  $comunityFastweb  $ipFastweb IF-MIB::ifInOctets.2   | awk '{print $4}'`
ifOutOctetsLastFastweb=`snmpget -v 1 -c $comunityFastweb  $ipFastweb IF-MIB::ifOutOctets.2   | awk '{print $4}'`




   let totalInFastweb=($ifInOctetsLastFastweb-$ifInOctetsFirstFastweb)*8*127/1000000/$drop
let totalOutFastweb=($ifOutOctetsLastFastweb-$ifOutOctetsFirstFastweb)*8*127/1000000/$drop

if [ $totalOutFastweb -gt 127 ]; then
totalOutFastweb=127
fi

if [ $totalInFastweb -gt 127 ]; then
totalInFastweb=127
fi

let totalOutFastweb=128+$totalOutFastweb
echo fastweb "<--" $totalInFastweb 
echo fastweb "-->" $totalOutFastweb 
/root/lptout $totalOutFastweb
/root/lptout $totalInFastweb
#echo $totalOutFastweb >> /dev/ttyUSB0
#echo $totalOutFastweb 
done
