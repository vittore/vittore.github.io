/**
A USB interface to the Microchip perf USB board
  Vittore Zen, vittore@zen.pn.it, 2011


                // Command 0x80: Update the device
                //          Byte[0] - Must be zero
                //			Byte[1] - The command 0x80
                //			Byte[2] - The left meter percentage 	(0-100) %
                //			Byte[3] - The right meter percentage	(0-100) %
                //			Byte[4] - The LED red value		    	(0-255) R
                //			Byte[5] - The LED green value			(0-255) G
                //			Byte[6] - The LED blue value			(0-255) B
                //          Byte[7] - Detach USB on button flag     (0-1) false, true

*/
#include <usb.h> /* libusb header */
#include <unistd.h> /* for geteuid */
#include <stdio.h>
#include <string.h>


/* PICkit USB values */ /* From Microchip firmware */
const static int vendorID=0x04d8; // Microchip, Inc
const static int productID=0x0044; // perf USB app
const static int configuration=1; /*  Configuration 1*/
const static int interface=0;	/* Interface 0 */

//const static int endpoint=1; /* first endpoint for everything */
const static int endpoint_in=0x81; /* endpoint 0x81 address for IN */
const static int endpoint_out=1; /* endpoint 1 address for OUT */

const static int timeout=5000; /* timeout in ms */

/* perf FS USB max packet size is 8-bytes */
const static int reqLen=8;
typedef unsigned char byte;

int led=1;

void bad(const char *why) {
	fprintf(stderr,"Fatal error> %s\n",why);
	exit(17);
}

/****************** Internal I/O Commands *****************/




/* debugging: enable debugging error messages in libusb */
extern int usb_debug;

/* Find the first USB device with this vendor and product.
   Exits on errors, like if the device couldn't be found.
*/
struct usb_dev_handle *usb_perf_fs_usb_open(void)
{
  struct usb_device * device;
  struct usb_bus * bus;
	char string[50];

#ifndef WIN32  
  if( geteuid()!=0 )
	 bad("This program must be run as root, or made setuid root");
#endif  
#ifdef USB_DEBUG
  usb_debug=4; 
#endif

  printf("Locating Microchip(tm) perf(tm) FS USB board (vendor 0x%04x/product 0x%04x)\n", vendorID, productID);
  usb_set_debug(255);
  printf("setting USB debug on by adding usb_set_debug(255) \n");
  
  usb_init();
  usb_find_busses();
  usb_find_devices();

  for (bus=usb_get_busses();bus!=NULL;bus=bus->next) 
  {
	 struct usb_device * usb_devices = bus->devices;
	 for( device=usb_devices; device!=NULL; device=device->next )
	 {
		if( device->descriptor.idVendor == vendorID &&
			device->descriptor.idProduct == productID )
		{
		   struct usb_dev_handle *d;
		   printf("Found USB perf FS USB board as device '%s' on USB bus %s\n",
				   device->filename,
				   device->bus->dirname);
			usb_reset(d);
		   d = usb_open(device);






		   if( d )
		   {
    int retval;
     char dname[32] = {0};
    retval = usb_get_driver_np(d, 0, dname, 31);
    if (!retval) {
      if (usb_detach_kernel_driver_np(d,interface)) {
         printf("Device detached successfully from the kernel\n");  
         }
      else {
         printf("Error detaching the device :-( \n");
      }
    }


			  if( usb_set_configuration(d, configuration) ) 
			  {
				 bad("Error setting USB configuration.\n");
			  }
			  if( retval=usb_claim_interface(d, interface) ) 
			  {
				 bad("Claim failed-- the USB perf FS USB is in use by another driver.\n");
			  }
			  printf("Communication established.\n");
			  
			  
			  printf("Interface Claim Status : %d\n",retval);

printf("Device Protocol : %d\n",device->descriptor.bDeviceProtocol);
printf("Report Length : %d\n",device->descriptor.bLength);
printf("Decriptor Type : %d\n",device->descriptor.bDescriptorType);
printf("End Points : %d\n",device->config->interface->altsetting->bNumEndpoints);
printf("Interface Class : %d\n",device->config->interface->altsetting->bInterfaceClass);
printf("Protocol : %d\n",device->config->interface->altsetting->bInterfaceProtocol);
printf("Interface Number: %d\n",device->config->interface->altsetting->bInterfaceNumber);
printf("Device Filename : %s\n",device->filename);

usb_get_string_simple(d,device->descriptor.iManufacturer,string,sizeof(string));
printf("Device Manfucaturer : %s\n",string);
usb_get_string_simple(d,device->descriptor.iProduct,string,sizeof(string));
printf("Product Name : %s\n",string);
usb_get_string_simple(d,device->descriptor.iSerialNumber,string,sizeof(string));
printf("Device Serial Number: %s\n",string);
printf("End point addresses : 0x%x\n",device->config->interface->altsetting->endpoint->bEndpointAddress);
			  
		  return d;
		   }
		   else 
			  bad("Open failed for USB device");
		}
		
		
	 }
  }
  bad("Could not find USB perf FS USB board--\n"
      "you might try lsusb to see if it's actually there.");
  return NULL;
}


/** Send this binary string command. */
static void send_usb(struct usb_dev_handle * d, int len, const char * src)
{
   int r = usb_interrupt_write(d, endpoint_out, (char *)src, len, timeout);
//   if( r != reqLen )
   if( r < 0 )
   {
	  perror("usb PICDEM FS USB write"); bad("USB write failed"); 
   }
}

/** Read this many bytes from this device */
static void recv_usb(struct usb_dev_handle * d, int len, byte * dest)
{
//   int i;
   int r = usb_interrupt_read(d, endpoint_in, dest, len, timeout);
   if( r != len )
   {
	  usb_reset(d);
   }
}


void testUP(struct usb_dev_handle * d) {
	int i;

	   byte answer[3];
   byte question[8];
	question[0]=0x80;
	question[1]=0;
	question[2]=100;
	question[3]=0;
	question[4]=0;
	question[5]=0;
	question[6]=0;
question[led+2]=255;
led++;
if (led>3) led=1;
	send_usb(d,  8,question);


       recv_usb(d, 2, answer);
 
	
   
   	}
void testDOWN(struct usb_dev_handle * d) {

	int i;

	   byte answer[3];
   byte question[8];
	question[0]=0x80;
	question[1]=100;
	question[2]=0;
	question[3]=0;
	question[4]=0;
	question[5]=0;
	question[6]=0;

	send_usb(d,  8,question);


       recv_usb(d, 2, answer);
 
	
   
	}

int main(int argc, char ** argv) 
{
int i;
	int j;
	int r;
	struct usb_dev_handle * perf_fs_usb = usb_perf_fs_usb_open();
	

	printf ("Start...\n");
	sleep(5);
	for(i=0;i<100;i++) {

			printf("\nUP");
		testUP(perf_fs_usb);
		sleep(1);
		printf("\nDOWN");
		testDOWN(perf_fs_usb);
			sleep(1);
		
	}
  usb_close(perf_fs_usb);
   return 0;
}
